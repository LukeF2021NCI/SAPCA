<!--
In this file will be the code for connection with database.
-->
<?php
$conn = mysqli_connect("localhost", "root", "", "Registrationdb");

if (!$conn) {
	echo "Database connection faild...";
}
?>